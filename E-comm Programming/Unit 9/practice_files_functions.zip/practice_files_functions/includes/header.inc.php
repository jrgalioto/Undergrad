<!doctype html>
<html>
<head>
	<title><?php if(isset($title)){ echo $title; }else{ echo 'E-Commerce'; } ?></title>
	<meta charset='utf-8'>
</head>
<body>